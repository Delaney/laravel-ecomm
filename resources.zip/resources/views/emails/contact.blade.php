You received a message from : {{ $contact['name'] }}
<p>
Name: {{ $contact['name'] }}
</p>
<p>
Email: {{ $contact['email'] }}
</p>
<p>
Phone: {{ $contact['phone'] }}
</p>
<p>
Message: {{ $contact['message'] }}
</p>